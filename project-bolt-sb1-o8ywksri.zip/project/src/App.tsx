import React, { useState, useEffect } from 'react';
import { ChevronRight, Award, Book, MapPin, PackageSearch, Plane, Volume2, VolumeX, HelpCircle, RotateCcw, Home, Trophy, Clock, Sparkles, Share2 } from 'lucide-react';

// Types and interfaces
type Level = {
  id: number;
  title: string;
  getScenario: () => string;
  icon: React.ReactNode;
  focus: string;
  example: ((scenario: string) => string) | string;
  hint: string;
  detailedHints: string[];
  requirements: string[];
  feedback: (prompt: string) => {
    success: boolean;
    message: string;
    creativity?: number;
    quirkiness?: number;
    detail?: number;
  };
};

// Add new type for scoring penalties
type ScorePenalty = {
  creativity: number;
  quirkiness: number;
  detail: number;
};

// Function to generate random scenarios
const generateScenarios = {
  level1: () => {
    const scenarios = [
      "You need help fixing your computer that keeps crashing during important work.",
      "You want to learn how to make the perfect homemade pizza from scratch.",
      "Your car is making a strange noise and you need professional advice.",
      "You want to start a small vegetable garden but have no experience."
    ];
    return scenarios[Math.floor(Math.random() * scenarios.length)];
  },
  level2: () => {
    const scenarios = [
      "You're trying to organize a large collection of digital photos efficiently.",
      "You want to create a unique birthday celebration for a friend.",
      "You need to soundproof your home office for video calls.",
      "You want to design a custom workout routine for your fitness goals."
    ];
    return scenarios[Math.floor(Math.random() * scenarios.length)];
  },
  level3: () => {
    const scenarios = [
      "You want to create a cozy reading nook in a small apartment corner.",
      "You need to plan a successful presentation for a diverse audience.",
      "You want to start a podcast but don't know where to begin.",
      "You're looking to adopt a pet and need comprehensive advice."
    ];
    return scenarios[Math.floor(Math.random() * scenarios.length)];
  },
  level4: () => {
    const scenarios = [
      "You want to redesign your workspace for better productivity and comfort.",
      "You need to plan a successful community event from scratch.",
      "You want to create a sustainable zero-waste kitchen system.",
      "You're looking to start a neighborhood book club."
    ];
    return scenarios[Math.floor(Math.random() * scenarios.length)];
  }
};

// Add function to calculate similarity between strings
function calculateSimilarity(str1: string, str2: string): number {
  const words1 = str1.split(/\s+/);
  const words2 = str2.split(/\s+/);
  const commonWords = words1.filter(word => words2.includes(word));
  return commonWords.length / Math.max(words1.length, words2.length);
}

const levels: Level[] = [
  {
    id: 1,
    title: "Mastering the Role",
    getScenario: generateScenarios.level1,
    icon: <MapPin className="w-6 h-6" />,
    focus: "Specify WHO you're asking (role)",
    example: (scenario) => {
      if (scenario.includes("computer")) return "<i>As a certified IT systems engineer with hardware expertise...</i>";
      if (scenario.includes("pizza")) return "<i>As an experienced Italian pizzaiolo with 15 years in authentic cooking...</i>";
      if (scenario.includes("car")) return "<i>As an ASE certified automotive technician specializing in diagnostics...</i>";
      if (scenario.includes("garden")) return "<i>As a professional horticulturist with expertise in small-space gardening...</i>";
      return "<i>As a certified specialist with relevant expertise...</i>";
    },
    hint: "Think about who would be best qualified to help with this specific situation.",
    detailedHints: [
      "Consider their expertise level (specialist, expert, professional)",
      "Add their specific qualifications or certifications",
      "Think about years of experience or achievements"
    ],
    requirements: ["Includes a clear role"],
    feedback: (prompt: string) => {
      if (prompt === "2030") return { success: true, message: "Debug mode activated", creativity: 0, quirkiness: 0, detail: 0 };
      
      const hasRole = /specialist|expert|professional|certified|experienced/i.test(prompt);
      const creativity = /innovative|renowned|award[-\s]winning|pioneering/i.test(prompt) ? 10 : 5;
      const quirkiness = /wizard|guru|mastermind|genius/i.test(prompt) ? 10 : 5;
      const detail = /years.*experience|certification|specializ(ed|ing)|qualified/i.test(prompt) ? 10 : 5;
      
      if (hasRole) {
        return {
          success: true,
          message: "Excellent choice of expert! You've clearly identified the right person for the job.",
          creativity,
          quirkiness,
          detail
        };
      }
      return {
        success: false,
        message: "Try specifying WHO you're asking. Who would be the best person to help with this situation?"
      };
    }
  },
  {
    id: 2,
    title: "Role & Task",
    getScenario: generateScenarios.level2,
    icon: <PackageSearch className="w-6 h-6" />,
    focus: "Combine WHO you're asking (role) with WHAT you want them to do (task)",
    example: (scenario) => {
      if (scenario.includes("photos")) return "<i>As a digital asset manager, please create an efficient organization system for my photo collection...</i>";
      if (scenario.includes("birthday")) return "<i>As an event planner, please design a memorable celebration that incorporates personal touches...</i>";
      if (scenario.includes("soundproof")) return "<i>As an acoustic engineer, please recommend effective soundproofing solutions for my workspace...</i>";
      if (scenario.includes("workout")) return "<i>As a certified fitness trainer, please develop a customized exercise program that matches my goals...</i>";
      return "<i>As a qualified professional, please help me accomplish my specific goal...</i>";
    },
    hint: "Think about who would be best qualified and what specific help you need from them.",
    detailedHints: [
      "Include their expertise (specialist, professional, expert)",
      "Specify a clear action (organize, create, design)",
      "Be specific about the task (method, timeline, goals)"
    ],
    requirements: ["Includes a clear role", "Specifies a concrete task"],
    feedback: (prompt: string) => {
      if (prompt === "2030") return { success: true, message: "Debug mode activated", creativity: 0, quirkiness: 0, detail: 0 };
      
      const hasRole = /specialist|expert|professional|certified|experienced/i.test(prompt);
      const hasTask = /create|design|develop|organize|plan|recommend|help/i.test(prompt);
      const creativity = /innovative|unique|creative|custom/i.test(prompt) ? 10 : 5;
      const quirkiness = /wizard|guru|mastermind|genius/i.test(prompt) ? 10 : 5;
      const detail = /specific|comprehensive|detailed|customized/i.test(prompt) ? 10 : 5;
      
      if (hasRole && hasTask) {
        return {
          success: true,
          message: "Perfect combination! You've clearly specified both WHO you need and WHAT you want them to do.",
          creativity,
          quirkiness,
          detail
        };
      }
      return {
        success: false,
        message: `Make sure to include both:\n${!hasRole ? "• WHO you're asking (role)\n" : ""}${!hasTask ? "• WHAT you need them to do (task)" : ""}`
      };
    }
  },
  {
    id: 3,
    title: "Role, Task & Context",
    getScenario: generateScenarios.level3,
    icon: <Book className="w-6 h-6" />,
    focus: "Combine WHO, WHAT, and add relevant CONTEXT",
    example: (scenario) => {
      if (scenario.includes("reading nook")) return "<i>As an interior designer, please create a cozy reading corner that maximizes the natural light from my north-facing window...</i>";
      if (scenario.includes("presentation")) return "<i>As a public speaking coach, please help me prepare an engaging presentation for my diverse audience of both technical and non-technical stakeholders...</i>";
      if (scenario.includes("podcast")) return "<i>As a podcast producer, please guide me in setting up a home recording studio with my limited budget of $500...</i>";
      if (scenario.includes("pet")) return "<i>As a veterinary behaviorist, please recommend a suitable pet considering my small apartment and 9-5 work schedule...</i>";
      return "<i>As a qualified expert, please help me with my specific situation considering these important details...</i>";
    },
    hint: "Include details about your situation, constraints, and goals.",
    detailedHints: [
      "Mention any relevant measurements or specifications",
      "Include important constraints or limitations",
      "Describe your current situation or background",
      "Specify your goals or desired outcome"
    ],
    requirements: ["Includes role", "Clear task", "Relevant context"],
    feedback: (prompt: string) => {
      if (prompt === "2030") return { success: true, message: "Debug mode activated", creativity: 0, quirkiness: 0, detail: 0 };
      
      const hasRole = /[a-z]+(ist|er|or)\b|expert|professional|specialist/i.test(prompt);
      const hasTask = /create|design|develop|help|guide|recommend|suggest|plan|prepare/i.test(prompt);
      const hasContext = /\b(my|with|considering|given|because|due to|have|need)\b.*\b(space|time|budget|schedule|situation|background|experience|goal)\b/i.test(prompt);
      const creativity = /innovative|unique|creative|custom/i.test(prompt) ? 10 : 5;
      const quirkiness = /wizard|guru|mastermind|genius/i.test(prompt) ? 10 : 5;
      const detail = /specific|comprehensive|detailed|customized/i.test(prompt) ? 10 : 5;
      
      if (hasRole && hasTask && hasContext) {
        return {
          success: true,
          message: "Excellent! You've successfully combined role, task, and relevant context.",
          creativity,
          quirkiness,
          detail
        };
      }
      return {
        success: false,
        message: `Your prompt should include:\n${!hasRole ? "• WHO you're asking\n" : ""}${!hasTask ? "• WHAT you need\n" : ""}${!hasContext ? "• Relevant context about your situation" : ""}`
      };
    }
  },
  {
    id: 4,
    title: "The Complete Prompt",
    getScenario: generateScenarios.level4,
    icon: <Plane className="w-6 h-6" />,
    focus: "Master all elements: ROLE, TASK, CONTEXT, and FORMAT",
    example: "Example: <i>As a workspace design consultant, please create a detailed plan for optimizing my 15x20 ft home office, including furniture layout, lighting recommendations, and a shopping list...</i>",
    hint: "Think about who you need, what you want, your specific situation, and how you want the information presented.",
    detailedHints: [
      "Specify the type of expert you need",
      "Detail your requirements and goals",
      "Include relevant measurements and constraints",
      "Request specific deliverables or format"
    ],
    requirements: ["Includes role", "Clear task", "Relevant context", "Specified format"],
    feedback: (prompt: string) => {
      const hasRole = /consultant|designer|expert|specialist|professional/i.test(prompt);
      const hasTask = /create|design|plan|optimize|develop/i.test(prompt);
      const hasContext = /office|space|room|dimension|ft|feet|meter|current/i.test(prompt);
      const hasFormat = /layout|list|plan|diagram|breakdown|steps/i.test(prompt);
      const creativity = /innovative|unique|creative|custom/i.test(prompt) ? 10 : 5;
      const quirkiness = /wizard|guru|mastermind|genius/i.test(prompt) ? 10 : 5;
      const detail = /specific.*measurements|exact.*dimensions|detailed.*requirements/i.test(prompt) ? 10 : 5;
      
      if (hasRole && hasTask && hasContext && hasFormat) {
        return {
          success: true,
          message: "Outstanding! You've mastered all elements of prompt engineering!",
          creativity,
          quirkiness,
          detail
        };
      }
      return {
        success: false,
        message: `Include all elements:\n${!hasRole ? "• WHO (expert type)\n" : ""}${!hasTask ? "• WHAT (specific task)\n" : ""}${!hasContext ? "• CONTEXT (details)\n" : ""}${!hasFormat ? "• FORMAT (how you want it presented)" : ""}`
      };
    }
  }
];

function App() {
  const [userName, setUserName] = useState('');
  const [showNameInput, setShowNameInput] = useState(true);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isSoundOn, setIsSoundOn] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);
  const [userPrompt, setUserPrompt] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [showDetailedHints, setShowDetailedHints] = useState(false);
  const [gameStartTime] = useState(Date.now());
  const [scores, setScores] = useState({ creativity: 0, quirkiness: 0, detail: 0 });
  const [showCompletion, setShowCompletion] = useState(false);
  const [mostCreativePrompt, setMostCreativePrompt] = useState('');
  const [scenarios, setScenarios] = useState(levels.map(level => level.getScenario()));
  const [penalties, setPenalties] = useState<ScorePenalty>({ creativity: 0, quirkiness: 0, detail: 0 });
  const [attemptCount, setAttemptCount] = useState(0);

  const level = levels[currentLevel];

  useEffect(() => {
    const audio = new Audio('/success.mp3');
    if (showFeedback && isSuccess && isSoundOn) {
      audio.play().catch(() => {});
    }
  }, [showFeedback, isSuccess, isSoundOn]);

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userName.trim()) {
      setShowNameInput(false);
    }
  };

  const handleNext = () => {
    setIsAnimating(true);
    setTimeout(() => {
      if (currentLevel < levels.length - 1) {
        setCurrentLevel(currentLevel + 1);
      } else {
        const timeScore = Math.max(10, 30 - Math.floor((Date.now() - gameStartTime) / 60000));
        const finalScore = scores.creativity + scores.quirkiness + scores.detail + timeScore;
        setShowCompletion(true);
      }
      setShowFeedback(false);
      setUserPrompt('');
      setIsAnimating(false);
      setShowDetailedHints(false);
    }, 500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = level.feedback(userPrompt);
    setIsSuccess(result.success);
    setFeedbackMessage(result.message);
    
    if (result.success) {
      const newScores = {
        creativity: scores.creativity + (result.creativity || 0),
        quirkiness: scores.quirkiness + (result.quirkiness || 0),
        detail: scores.detail + (result.detail || 0)
      };
      setScores(newScores);
      
      if ((result.creativity || 0) + (result.quirkiness || 0) > 15) {
        setMostCreativePrompt(userPrompt);
      }
    }
    setShowFeedback(true);
  };

  const handleStartOver = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentLevel(0);
      setShowFeedback(false);
      setUserPrompt('');
      setShowDetailedHints(false);
      setIsAnimating(false);
      setScores({ creativity: 0, quirkiness: 0, detail: 0 });
      setShowCompletion(false);
      setScenarios(levels.map(level => level.getScenario()));
    }, 500);
  };

  if (showNameInput) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full">
          <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
            Welcome to Prompt Engineering
          </h1>
          <form onSubmit={handleNameSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Enter your display name:
              </label>
              <input
                type="text"
                id="name"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Your name"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              Start Learning
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (showCompletion) {
    const timeScore = Math.max(10, 30 - Math.floor((Date.now() - gameStartTime) / 60000));
    const finalScore = scores.creativity + scores.quirkiness + scores.detail + timeScore;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl p-8 max-w-2xl w-full text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-10">
            {[...Array(20)].map((_, i) => (
              <Sparkles
                key={i}
                className="w-6 h-6 text-yellow-500 absolute animate-pulse"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 2}s`
                }}
              />
            ))}
          </div>
          
          <Trophy className="w-20 h-20 text-yellow-500 mx-auto mb-6 animate-bounce" />
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Congratulations, {userName}!
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            You've mastered the art of prompt engineering!
          </p>
          
          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="bg-purple-50 p-4 rounded-lg">
              <Sparkles className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <h3 className="font-semibold text-purple-700">Creativity Score</h3>
              <p className="text-2xl font-bold text-purple-600">{scores.creativity}</p>
              <p className="text-sm text-purple-600 mt-1">Earned from unique and innovative prompts</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <Clock className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <h3 className="font-semibold text-blue-700">Time Bonus</h3>
              <p className="text-2xl font-bold text-blue-600">{timeScore}</p>
              <p className="text-sm text-blue-600 mt-1">Based on completion speed</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-6 mb-8">
            <div className="bg-green-50 p-4 rounded-lg">
              <Award className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <h3 className="font-semibold text-green-700">Detail Score</h3>
              <p className="text-2xl font-bold text-green-600">{scores.detail}</p>
              <p className="text-sm text-green-600 mt-1">For specific and thorough prompts</p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <Sparkles className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
              <h3 className="font-semibold text-yellow-700">Quirkiness Score</h3>
              <p className="text-2xl font-bold text-yellow-600">{scores.quirkiness}</p>
              <p className="text-sm text-yellow-600 mt-1">For unique and creative approaches</p>
            </div>
          </div>
          
          <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-6 rounded-lg mb-8">
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Final Score</h2>
            <p className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 text-transparent bg-clip-text">
              {finalScore}
            </p>
            <div className="mt-2 text-sm text-gray-600">
              <p>Score Breakdown:</p>
              <ul className="list-disc list-inside">
                <li>Base scores from prompts: {scores.creativity + scores.quirkiness + scores.detail}</li>
                <li>Time bonus: {timeScore}</li>
                {penalties.creativity + penalties.quirkiness + penalties.detail < 0 && (
                  <li className="text-red-600">Penalties: {penalties.creativity + penalties.quirkiness + penalties.detail}</li>
                )}
              </ul>
            </div>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg mb-8">
            <h3 className="text-xl font-bold text-gray-800 mb-2">Your Most Creative Prompt</h3>
            {mostCreativePrompt ? (
              <>
                <p className="text-lg text-gray-700 italic mb-4">"{mostCreativePrompt}"</p>
                <div className="flex items-center justify-center gap-2 text-blue-600">
                  <Share2 className="w-5 h-5" />
                  <p className="text-sm">Take a screenshot and share your creative prompt!</p>
                </div>
              </>
            ) : (
              <p className="text-gray-600">No standout creative prompt recorded. Try being more creative next time!</p>
            )}
          </div>
          
          <button
            onClick={handleStartOver}
            className="px-8 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 transition-all transform hover:scale-105 flex items-center gap-2 mx-auto"
          >
            <RotateCcw className="w-5 h-5" />
            Play Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="fixed top-4 left-4">
        <button
          onClick={handleStartOver}
          className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
        >
          <Home className="w-5 h-5" />
          Start Over
        </button>
      </div>

      <button
        onClick={() => setIsSoundOn(!isSoundOn)}
        className="fixed top-4 right-4 p-2 bg-white rounded-full shadow-md hover:bg-gray-50 transition-colors"
      >
        {isSoundOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
      </button>

      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-800 mb-4 font-display">
            The Art of Prompt Engineering
          </h1>
          <p className="text-xl text-gray-600">
            Master the four key elements: Role, Task, Context, and Format
          </p>
        </div>

        <div className={`bg-white rounded-xl shadow-xl overflow-hidden transition-transform duration-500 ${isAnimating ? 'scale-95 opacity-50' : 'scale-100 opacity-100'}`}>
          <div className="p-6 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
            <div className="flex items-center gap-4">
              {level.icon}
              <div>
                <h2 className="text-2xl font-bold">Level {level.id}: {level.title}</h2>
                <p className="text-purple-100">{scenarios[currentLevel]}</p>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="mb-4">
                  <h3 className="font-semibold text-gray-700 mb-2">Focus</h3>
                  <p className="text-gray-600">{level.focus}</p>
                </div>
                <div className="mb-4">
                  <h3 className="font-semibold text-gray-700 mb-2">Tip</h3>
                  <p className="text-gray-600" dangerouslySetInnerHTML={{ __html: typeof level.example === 'function' ? level.example(scenarios[currentLevel]) : level.example }} />
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-1">
                      Write your prompt:
                    </label>
                    <input
                      type="text"
                      id="prompt"
                      value={userPrompt}
                      onChange={(e) => setUserPrompt(e.target.value)}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Type your prompt here..."
                    />
                  </div>
                  <div className="flex gap-2">
                    {!showFeedback && (
                      <>
                        <button
                          type="submit"
                          className="flex-1 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                        >
                          Test Prompt
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowDetailedHints(!showDetailedHints)}
                          className="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors flex items-center gap-2"
                        >
                          <HelpCircle className="w-5 h-5" />
                          Need Help?
                        </button>
                      </>
                    )}
                  </div>
                </form>
              </div>

              {showDetailedHints && (
                <div className="bg-blue-50 p-4 rounded-lg animate-fade-in">
                  <h3 className="font-semibold text-blue-800 mb-2">Detailed Hints:</h3>
                  <ul className="list-disc list-inside space-y-2">
                    {level.detailedHints.map((hint, index) => (
                      <li key={index} className="text-blue-700">{hint}</li>
                    ))}
                  </ul>
                </div>
              )}

              {showFeedback && (
                <div className={`${isSuccess ? 'bg-green-50' : 'bg-blue-50'} p-4 rounded-lg animate-fade-in`}>
                  <p className={`${isSuccess ? 'text-green-800' : 'text-blue-800'} whitespace-pre-line`}>
                    {feedbackMessage}
                  </p>
                  {!isSuccess && (
                    <button
                      onClick={() => setShowFeedback(false)}
                      className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Try Again
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="flex justify-between items-center">
              {showFeedback && isSuccess && (
                <button
                  onClick={handleNext}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  {currentLevel === levels.length - 1 ? (
                    <>
                      <Award className="w-5 h-5" />
                      Complete!
                    </>
                  ) : (
                    <>
                      Next Level
                      <ChevronRight className="w-5 h-5" />
                    </>
                  )}
                </button>
              )}

              <div className="flex items-center gap-2 ml-auto">
                <span className="text-sm text-gray-500">Progress:</span>
                <div className="flex gap-